<?php include("../config.php"); ?>
<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:index.php?pesan=belum_login");
	}
	?>


<!DOCTYPE html>
<html>
<head>
 <!-- Required meta tags -->
 <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
 <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
<meta name="HandheldFriendly" content="true">
<nav class="navbar navbar-dark navbar-light bg-primary"> <!-- Navbar content --> </nav>

<body class="app sidebar-hidden"> 

<!-- JANGAN HILANGKAN CREDIT -->
<meta name="author"content="Shodik12">

<!-- Font Awesome 5-->
<link rel="stylesheet" href="./css/fontawesome.css">
<!-- Font Awesome-->
<link rel="stylesheet" href="./css/fontawesome.min.css">
<script src="js/fontawesome.js"></script>
  <script src="js/fontawesome.min.js"></script>

  <!-- CoreUI CSS -->
  <link rel="stylesheet" href="./css/coreui.min.css">

   <script src="https://kit.fontawesome.com/a076d05399.js"></script>

  <link rel="stylesheet" href="./css/modal.css">


	<title>Web Kelas</title>
</head>
<nav class="navbar navbar-expand-lg navbar-secondary navbar-light bg-secondary"> <h5>Web Kelas</h5><button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button> <div class="collapse navbar-collapse" id="navbarTogglerDemo01"> <ul class="navbar-nav mr-auto mt-2 mt-lg-0"> <li class="nav-item active"> <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a> </li> <li class="nav-item">
 <a class="nav-link" href="62895364386346">Kontak Admin(Dev)</a> </li> 
<a class="btn btn-danger" href="./logout.php">Logout</a>
<hr>

</ul>  </div> </nav>
<body>

	<br>
	<div class="card">
<script>

var Digital=new Date()

var hours=Digital.getHours()


//Silahkan sesuaikan dengan pesan yang Anda inginkan

if (hours>=5&&hours<=11) //pesan pagi hari (05.00-11.00)

document.write('<b>Selamat Pagi <?php echo $_SESSION['nama']; ?>!</b>')

else if (hours==12) //pesan siang hari (12.00-13.00)

document.write('<b>Selamat Siang <?php echo $_SESSION['nama']; ?>!</b>')

else if (hours>=13&&hours<=17) //pesan sore hari(14.00-17.00)

document.write('<b>Selamat Sore <?php echo $_SESSION['nama']; ?>!.</b>')

else if (hours>=18&&hours<=20) //pesan petang hari (18.oo-20.00)

document.write('<b>Selamat Petang <?php echo $_SESSION['nama']; ?>!</b>')

else if (hours>=21&&hours<=11) //pesan malam hari (21.00-23.00)

document.write('<b>Selamat Malam<?php echo $_SESSION['nama']; ?> !</b>')

else //pesan malam mejelang pagi(00.00-04.00)

document.write('<b>Selamat Malam <?php echo $_SESSION['nama']; ?>!</b>')

//edit by http://www.masbugie.com

</script>


<div class="container">
<div class="card bg-ligth text-primary"> <img class="card-img" src="bg/bg.png" alt="Card image"> <div class="card-img-overlay"> <h5 class="card-title">Web Kelas</h5> <p class="card-text"></p> <p class="card-text"></p> </div> </div></div>




      <div class="alert alert-primary" role="alert">
      <div class="card-header">
    		<h3>Daftar Siswa</h3>
  </div>
</div>





 <div class="card-body">
	<table class="table  table-responsive  table-striped table-bordered ">




	<thead>
		<tr>
			
<th><button type="button" class="btn btn-secondary btn-pill ">No</button></th>

			<th><button type="button" class="btn btn-secondary btn-pill ">Nama</button></th>

			<th><button type="button" class="btn btn-secondary btn-pill ">Jenis Kelamin</button></th>

		</tr>
	</thead>
	<tbody>

		<?php
		$sql = "SELECT * FROM calon_siswa";
		$query = mysqli_query($connect, $sql);

$no = 1;
		while($siswa = mysqli_fetch_array($query)){
			echo "<tr>";
			echo "<td><button type='button' class='btn btn-warning'>".$no."</button></td>";
			echo "<td><button type='button' class='btn btn-primary'>".$siswa['nama']."</button></td>";
			echo "<td><button type='button' class='btn btn-primary'>".$siswa['jenis_kelamin']."</button></td>";
echo "<td>";
			
			
			echo "</td>";
			
$no++;
		}
		?>

	</tbody>
	</table>

   <button type="button" class="btn btn-square btn-primary">
	Total Siswa: <?php echo mysqli_num_rows($query) ?></button>


	</div>
</div>
	</body>






  <div class="container-fluid">

<div class="card card-accent-primary mb-3" style="max-width: 100rem;"> <div class="card-header"><h5><button class="button btn-secondary">Info Kelas</h5></button>
</div> <div class="card-body text-primary"> <h5 class="card-title"> <p class="card-text">

<table class="table table-striped table-bordered table-responsive">
	<thead>
		<tr>
			<th>No</th>
			<th>Info Kelas</th>
			<th>Jenis Info</th>
         


		</tr>
	</thead>
	<tbody>

		<?php
		$sql = "SELECT * FROM edit_article";
		$query = mysqli_query($connect, $sql);
$no = 1;
		while($posting = mysqli_fetch_array($query)){
			echo "<tr>";
			echo "<td>".$no."</td>";
			echo "<td>".$posting['isi']."</td>";
			echo "<td><button type='button' class='btn btn-square btn-primary '>".$posting['jenis_article']."</button></td>";




$no++;
		}
		?>

	</tbody>
	</table>

</p> </div> </div></div>

<div class="container-fluid">
<div class="card card-accent-primary mb-3" style="max-width: 100rem;"> <div class="card-header"><h5><button class="button btn-secondary">Jadwal Pelajaran</h5></button></div> <div class="card-body text-primary"> <h5 class="card-title"> <p class="card-text">

<table class="table table-striped table-bordered table-responsive">
	<thead>
		<tr>
			<th>No</th>
			<th>Senin</th>
			<th>Selasa</th>

<th>Rabu</th>
			<th>Kamis</th>
<th>Jumat</th>

		</tr>
	</thead>
	<tbody>

		<?php
		$sql = "SELECT * FROM jadwal_mapel";
		$query = mysqli_query($connect, $sql);
$no = 1;
		while($jadwal = mysqli_fetch_array($query)){
			echo "<tr>";
			echo "<td>".$no."</td>";
			echo "<td>".$jadwal['senin']."</td>";
			echo "<td>".$jadwal['selasa']."</td>";
			echo "<td>".$jadwal['rabu']."</td>";		
echo "<td>".$jadwal['kamis']."</td>";
			echo "<td>".$jadwal['jumat']."</td>";




echo"</tr>";
$no++;

}
		?>

	</tbody>
	</table>

</p> </div> </div></div>



<div class="container-fluid">
<div class="card card-accent-primary mb-3" style="max-width: 100rem;"> <div class="card-header"><h5><button class="button btn-secondary">Daftar Absen</h5></button>
<div class="alert alert-primary" role="alert"> Jika Siswa Belum Absen Segera Absen! </div>

</div> <div class="card-body text-primary"> <h5 class="card-title"> <p class="card-text">

<?php if(isset($_GET['status-absen'])): ?>
	<p>
		<?php
			if($_GET['status-absen'] == 'sukses'){
				echo "<div class='alert alert-success' role='alert'>  berhasil di absen!</div>";
			} else {
				echo "gagal!";
			}
		?>
	</p>
	<?php endif; ?>


<button type="button" class="btn btn-primary">Siswa Yang Sudah Absen</button>

<table class="table table-striped table-bordered table-responsive">
	<thead>
		<tr>
			<th>No</th>
			<th>Nama</th>
		<th>Tanggal</th>
<th>Keterangan</th>
	
		</tr>
</thead>



	
	<tbody>

		<?php
		$sql = "SELECT * FROM user";
		$query = mysqli_query($connect, $sql);
$no = 1;
		while($absen= mysqli_fetch_array($query)){
			echo "<tr>";
			echo "<td>".$no."</td>";
			echo "<td>".$absen['nama']."</td>";
				echo "<td>".$absen['hari']."</td>";		
echo "<td>".$absen['ket']."</td>";
	

echo "</tr>";
$no++;
}
		?>
</tbody>

	</table>
<div class="alert alert-primary" role="alert"> Belum Absen??? Klik Absen Lalu Isi Formulir ! </div>
<!-- Button trigger modal --> <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"> 
Absen </button> 

<!-- Modal -->
 <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true"> <div class="modal-dialog" role="document">
 <div class="modal-content"> 
<div class="modal-header"> 
<h5 class="modal-title" id="exampleModalLabel">Formulir Absen Siswa</h5> 
<button type="button" class="close" data-dismiss="modal" aria-label="Close"> 
<span aria-hidden="true">&times;</span> 
</button> 
</div>
 <div class="modal-body"> 

<form action="proses-absen.php" method="POST">
<div class="mb-3">
 <label for="exampleInputEmail1">Nama</label> 
<input type="text" class="form-control" id="exampleInputPassword1" aria-describedby="emailHelp" name="nama"> 
</div> 


<div class="mb-3"> 
<label for="exampleInputPassword1">Tanggal/Bulan/tahun</label> <input type="date" class="form-control" id="exampleInputPassword1" name="hari"> </div>


<div class="mb-3"> 
<label for="exampleInputPassword1">Keterangan</label> <input type="text" class="form-control" id="exampleInputPassword1" name="ket"> </div>






 <button type="submit" class="btn btn-primary" name="absen">Submit</button> </form>


</div>

 <div class="modal-footer"> 
<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>  </div> </div> </div> </div>


<hr>

<button class="btn btn-primary">Absen Foto</button>


<table class="table table-striped table-bordered table-responsive">
	<thead>
		<tr>
			<th>No</th>
			<th>Foto</th>
	     
		</tr>
</thead>



	
<tbody>

<?php
		$sql = "SELECT * FROM fotouser";
		$query = mysqli_query($connect, $sql);
$no = 1;
		while($fotouser= mysqli_fetch_array($query)){
			echo "<tr>";
          echo "<td>".$no."</td>";
			echo "<td><img src='foto/".$fotouser['foto']."' width='100' height='100'></td>";
				
		echo "<td><button type='button' class='btn btn-secondary'><a href='foto/".$fotouser['foto']."'>Lihat Foto</a></button></td>";





echo "</tr>";
$no++;
}
		?>

	</tbody>

	</table>


</p> </div> 
<div class="alert alert-primary" role="alert"> Belum Absen Foto??? Klik Pilih File Lalu Upload! </div>
<div class="card"> 
<div class="card-body"> 
<h4 class="card-title">Form Upload</h4> 
<p class="card-text"><div class="container-fluid"><body>

<form method="post" enctype="multipart/form-data" action="upload-foto.php">
	

<div class="input-group mb-3"> 
<input type="file" class="btn btn-outline-primary" name="foto"><br>
	<input type="submit" class="btn btn-primary" value="Upload">
</div> 




</form>
</body>
</div>

</div></div>
<br>







<div class"container-fluid">
<div class="card card-accent-primary mb-3" style="max-width: 100rem;"> <div class="card-header"><h5><button class="button btn-secondary">Daftar Penugasan</h5></button>

</div> <div class="card-body text-primary"> <h5 class="card-title"> <p class="card-text">
<button type="button" class="btn btn-primary">Daftar Penugasan</button>

<table class="table table-striped table-bordered table-responsive">



	<thead>
		<tr>
			<th>No</th>
			<th>Mata Pelajaran</th>
		<th>Materi</th>

	


		

		</tr>




	</thead>
	<tbody>

		<?php
		$sql = "SELECT * FROM tugas";
		$query = mysqli_query($connect, $sql);

$no = 1;
		while($nugas= mysqli_fetch_array($query)){
			echo "<tr>";
			echo "<td>".$no."</td>";
			echo "<td>".$nugas['mapel']."</td>";
				echo "<td>".$nugas['materi']." </td>";		




		echo "</tr>";
$no++;
}
		?>

	</tbody>
	</table>

</p> </div> </div></div>






<div class="container-fluid">
<div class="card">
 <div class="card-body">
<tr>
		
			<button type="button" class="btn btn-secondary btn-light"><span class="cid-camera btn-icon mr-2"></span> <h5><th>Galeri Foto</th></h5></button>
		
<div class="alert alert-primary" role="alert"> Disini Penugasan Berupa Foto! </div>


		</tr><br>

	

		<?php
		$sql = "SELECT * FROM gambar";
		$query = mysqli_query($connect, $sql);

$no = 1;
		while($data = mysqli_fetch_array($query)){
			echo "<tr>";
echo "<hr>";
echo"<button type='button' class='btn btn-primary'><span class='badge badge-secondary'><h5>".$no."</h5></span></button><br><button class='btn btn-ligth'>Nama File: ".$data['nama']."</button><br><button type='button' class='btn btn-secondary'><a href='images/".$data['nama']."'>Lihat Foto</a></button>";






			echo "<div class='card' style='width: 18rem;'> <td><img src='images/".$data['nama']."' width='270' height='270'></td></div>";



          echo "</tr>";


$no++;
		}
		?>

	

	</div>
</div>
</div>



<div cass="container-fluid">
<div class="card">
 <div class="card-body">
<tr>
		
			<button type="button" class="btn btn-secondary btn-light"><span class="cid-camera btn-icon mr-2"></span> <h5><th>Galeri Pdf</th></h5></button>
		


<div class="alert alert-primary" role="alert"> Disini Penugasan Berupa File Pdf! </div>
		</tr><br>

	

		<?php
		$sql = "SELECT * FROM pdf";
		$query = mysqli_query($connect, $sql);
$no = 1;
		while($pdf = mysqli_fetch_array($query)){
			echo "<tr>";

echo "<hr>";
echo"<button type='button' class='btn btn-primary btn-pill'><span class='badge badge-secondary'><h5>".$no."</h5></span></button><br><button class='btn btn-ligth'> Nama File:".$pdf['nama_pdf']."</button><br><a class='btn btn-primary' href='files/".$pdf['nama_pdf']."' role='button'>Download</a>";




echo "<br>";



			echo "<embed src='files/".$pdf['nama_pdf']."' type='application/pdf' width='100%' height='300px'><br>";



          echo "</tr>";


$no++;
		}
		?>

	

	</div>
</div>
</div>


<div class="container-fluid">
<div class="card">
 <div class="card-body">
<tr>
		
			<button type="button" class="btn btn-secondary btn-light"><span class="cid-camera btn-icon mr-2"></span> <h5><th>Galeri Video</th></h5></button>
		
<div class="alert alert-primary" role="alert"> Disini Penugasan Berupa Video! </div>


		</tr><br>

	

		<?php
		$sql = "SELECT * FROM video";
		$query = mysqli_query($connect, $sql);

$no = 1; // Untuk penomoran tabel, di awal set dengan 1
		while($video = mysqli_fetch_array($query)){
			echo "<tr>";

echo "<hr>";
echo"<button type='button' class='btn btn-primary btn-pill'><span class='badge badge-secondary'><h5>".$no."</h5></span></button><br><button class='btn btn-ligth'>Nama Video: ".$video['nama_video']."</button><br><a class='btn btn-primary' href='video/".$video['nama_video']."' role='button'>Download</a>";


echo "<br>";

			echo "<video width='400px' height='200px' controls><source src='video/".$video['nama_video']."' type='video/mp4'></video><br>";




          echo "</tr>";

$no++;

		}
		?>

	

	</div>
</div></div>


<div class="container-fluid">
<div class="card">
 <div class="card-body">
<tr>
		
<?php if(isset($_GET['status-pdf'])): ?>
	<p>
		<?php
			if($_GET['status-pdf'] == 'sukses'){
				echo "<div class='alert alert-success' role='alert'>  jawaban berupa File(Pdf) dari Siswa berhasil diserahkan!</div>";
			} else {
				echo "gagal!";
			}
		?>
	</p>
	<?php endif; ?>


			<button type="button" class="btn btn-secondary btn-light"><span class="cid-camera btn-icon mr-2"></span> <h5><th>Galeri  Jawaban Siswa Pdf</th></h5></button>
		
<div class="alert alert-primary" role="alert"> Disini Jawaban Siswa Yang Sudah Menyerahkan Tugas Berupa File Pdf ! </div>

		</tr>





		<?php
		$sql = "SELECT * FROM pdfuser";
		$query = mysqli_query($connect, $sql);
$no = 1;
		while($pdfuser = mysqli_fetch_array($query)){
			echo "<tr>";


echo"<hr><button type='button' class='btn btn-primary btn-pill'><span class='badge badge-secondary'><h5>".$no."</h5></span></button><br><button class='btn btn-ligth'><h4>Nama File: ".$pdfuser['userpdf']."</h4></button>";








			


          echo "</tr>";

$no++;

		}
		?>


		

	</div>

<div class="card"> 
<h4 class="card-header">Serahkan Jawaban Berupa File PDF</h4> 
<div class="card-body"> 
<h4 class="card-title">Form Upload</h4> 
<p class="card-text"><div class="container-fluid"><body>

<form method="post" enctype="multipart/form-data" action="upload-pdfuser.php">
	

<div class="input-group mb-3"> 
<input type="file" class="btn btn-outline-primary" name="pdf" required><br>
	<input type="submit" class="btn btn-primary" value="Upload">
</div> 




</form>
<br>



<form method="post"  action="proses-serahpdf.php">
	
<h4 class="card-header">Setelah Selesai Upload Tugas File Pdf,lalu isi nama dibawah ,untuk menyatakan bahwa sudah menyerahkan</h4> 
<div class="input-group mb-3"> 
<input type="text" class="btn btn-outline-primary" name="nama" placeholder="isi nama" required><br>
	<input type="submit" class="btn btn-primary" name="serahkan" value="Upload">
</div> 




</form>
	

<?php
		$sql = "SELECT * FROM serahpdf";
		$query = mysqli_query($connect, $sql);
$no = 1;
		while($serahpdf = mysqli_fetch_array($query)){
			echo "<tr>";

echo "<hr>";
echo"<button type='button' class='btn btn-primary btn-pill'><span class='badge badge-secondary'><h5>".$no."</h5></span></button><br><button class='btn btn-ligth'><h3>Nama Yang Sudah Menyerahkan:</h3><button class='btn btn-pill btn-primary'> ".$serahpdf['nama']."</button></button><br>";




echo "<br>";



			


          echo "</tr>";

$no++;

		}
		?>
</body>
</div>

</p>
 </div> </div>




</div></div>


<div class="container-fluid">
<div class="card">
 <div class="card-body">
<tr>

<?php if(isset($_GET['status-audio'])): ?>
	<p>
		<?php
			if($_GET['status-audio'] == 'sukses'){
				echo "<div class='alert alert-success' role='alert'>  jawaban berupa audio(Mp3) dari Siswa berhasil diserahkan!</div>";
			} else {
				echo "gagal!";
			}
		?>
	</p>
	<?php endif; ?>


		
			<button type="button" class="btn btn-secondary btn-light"><span class="cid-camera btn-icon mr-2"></span> <h5>
<th>Galeri  Jawaban Siswa Audio</th></h5></button>
		<div class="alert alert-primary" role="alert"> Disini Jawaban Siswa Yang Sudah Menyerahkan Tugas Berupa File Audio/mp3! </div>



		</tr><br>

	

		<?php
		$sql = "SELECT * FROM audio";
		$query = mysqli_query($connect, $sql);
$no = 1;
		while($audio = mysqli_fetch_array($query)){
			echo "<tr>";

echo "<hr>";
echo"<button type='button' class='btn btn-primary btn-pill'><span class='badge badge-secondary'><h5>".$no."</h5></span></button><br>Nama Audio:".$audio['mptri']."<br>";




echo "<br>";



			




          echo "</tr>";

$no++;

		}
		?>

	

	</div>
</div>
<div class="card"> 
<h4 class="card-header">Serahkan Jawaban Berupa File Mp3</h4> 
<div class="card-body"> 
<h4 class="card-title">Form Upload</h4> 
<p class="card-text"><div class="container-fluid"><body>

<form method="post" enctype="multipart/form-data" action="upload-audio.php">
	

<div class="input-group mb-3"> 
<input type="file" class="btn btn-outline-primary" name="audio"><br>
	<input type="submit" class="btn btn-primary" value="Upload">
</div> 




</form>

<form method="post"  action="proses-serahaudio.php">
	
<h4 class="card-header">Setelah Selesai Upload Tugas File Audio,lalu isi nama dibawah ,untuk menyatakan bahwa sudah menyerahkan</h4> 
<div class="input-group mb-3"> 
<input type="text" class="btn btn-outline-primary" name="nama" placeholder="isi nama" required><br>
	<input type="submit" class="btn btn-primary" name="serahkan" value="Upload">
</div> 




</form>
	

<?php
		$sql = "SELECT * FROM serahaudio";
		$query = mysqli_query($connect, $sql);
$no = 1;
		while($serahaudio = mysqli_fetch_array($query)){
			echo "<tr>";

echo "<hr>";
echo"<button type='button' class='btn btn-primary btn-pill'><span class='badge badge-secondary'><h5>".$no."</h5></span></button><br><button class='btn btn-ligth'><h3>Nama Yang Sudah Menyerahkan:</h3><button class='btn btn-pill btn-primary'> ".$serahaudio['nama']."</button></button><br>";



echo "<br>";



			


          echo "</tr>";

$no++;

		}
		?>




</body>
</div>

</p>
 </div> </div>

</div>


<div class="container-fluid">
<div class="card">
 <div class="card-body">
<tr>
		
			<button type="button" class="btn btn-secondary btn-light"><span class="cid-camera btn-icon mr-2"></span> <h5><th>Galeri  Jawaban Siswa Foto/Gambar</th></h5></button>
		<div class="alert alert-primary" role="alert"> Disini Jawaban Siswa Yang Sudah Menyerahkan Tugas Berupa Foto/Gambar! </div>



		</tr><br>

	

		<?php
		$sql = "SELECT * FROM gambaruser";
		$query = mysqli_query($connect, $sql);
$no = 1;
		while($gambaruser = mysqli_fetch_array($query)){
			echo "<tr>";

echo "<hr>";
echo"<button type='button' class='btn btn-primary btn-pill'><span class='badge badge-secondary'><h5>".$no."</h5></span></button><br>Nama Foto/Gambar:".$gambaruser['gambaruser']."<br>";




echo "<br>";



			

echo "<img src='gambar/".$gambaruser['gambaruser']."' width='200' height='200'>";



          echo "</tr>";

$no++;

		}
		?>

	

	</div>
</div>
<div class="card"> 
<h4 class="card-header">Serahkan Jawaban Berupa Foto/Gambar</h4> 
<div class="card-body"> 
<h4 class="card-title">Form Upload</h4> 
<p class="card-text"><div class="container-fluid"><body>

<form method="post" enctype="multipart/form-data" action="upload-gambaruser.php">
	

<div class="input-group mb-3"> 
<input type="file" class="btn btn-outline-primary" name="gambaruser"><br>
	<input type="submit" class="btn btn-primary" value="Upload">
</div> 




</form>

<form method="post"  action="proses-serahgambar.php">
	
<h4 class="card-header">Setelah Selesai Upload Tugas File Foto/Gambar,lalu isi nama dibawah ,untuk menyatakan bahwa sudah menyerahkan</h4> 
<div class="input-group mb-3"> 
<input type="text" class="btn btn-outline-primary" name="nama" placeholder="isi nama" required><br>
	<input type="submit" class="btn btn-primary" name="serahkan" value="Upload">
</div> 




</form>
	

<?php
		$sql = "SELECT * FROM serahgambar";
		$query = mysqli_query($connect, $sql);
$no = 1;
		while($serahgambar = mysqli_fetch_array($query)){
			echo "<tr>";

echo "<hr>";
echo"<button type='button' class='btn btn-primary btn-pill'><span class='badge badge-secondary'><h5>".$no."</h5></span></button><br><button class='btn btn-ligth'><h3>Nama Yang Sudah Menyerahkan:</h3><button class='btn btn-pill btn-primary'> ".$serahgambar['nama']."</button></button><br>";



echo "<br>";



			


          echo "</tr>";

$no++;

		}
		?>






</body>
</div>

</p>
 </div> </div>
<button type="button" class="btn btn-square btn-primary">
	Total Siswa Yang Sudah Menyerahkan File Foto/Gambar: <?php echo mysqli_num_rows($query) ?></button>

</div>













  <script src="https://unpkg.com/@popperjs/core@2"></script> <script src="./js/coreui.min.js"></script>

  <script src=".js/modal.js"></script>


  <script src=".js/coreui.bundle.js"></script>
</body>
</html>
