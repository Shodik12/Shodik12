<?php 
// mengaktifkan session php
session_start();

// menghubungkan dengan koneksi
include '../config.php';

// menangkap data yang dikirim dari form
$username =  mysqli_real_escape_string($connect,$_POST['nama']);
$password = mysqli_real_escape_string($connect, $_POST['password']);



// menyeleksi data admin dengan username dan password yang sesuai
$query = mysqli_query($connect,"select * from logins where nama='$username' and password='$password'");

// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($query);

// cek apakah username dan password di temukan pada database
if($cek > 0){
	$_SESSION['nama'] = $username;
	$_SESSION['status'] = "login";
	header("location:indexadmin.php");
}else{
	header("location:index.php?pesan=gagal");
}
mysqli_close($connect);

if($_SESSION["Captcha"]!=$_POST["nilaiCaptcha"]){
			header("location:index.php?pesan=salah");
		}else{		
			echo "<p>Captcha Anda Benar</p>";
		}

?>
