
<?php include("../config.php"); ?>

<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:index.php?pesan=belum_login");
	}
	?>


<!DOCTYPE html>
<html>

 <!-- Required meta tags --> <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
<nav class="navbar navbar-dark navbar-light bg-primary"> <!-- Navbar content --> </nav>

<head>
	<title>Formulir Tambah Foto</title>
</head>
<!-- JANGAN HILANGKAN CREDIT -->
<meta name="author"content="Shodik12">

<!-- Font Awesome 5-->
<link rel="stylesheet" href="css/fontawesome.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
 <script src="js/fontawesome.js"></script>
<script src="js/fontawesome.min.js"></script>

  <!-- CoreUI CSS -->
  <link rel="stylesheet" href="css/coreui.min.css">

   <script src="https://kit.fontawesome.com/a076d05399.js"></script>

  <link rel="stylesheet" href="css/modal.css">

<body>
	<header>
		<h3>Formulir Tambah Foto</h3>
	</header>

<div class="card">
 <div class="card-body"> 


 <form method="post" enctype="multipart/form-data" action="upload-foto.php">
	<input type="file" name="foto">
	<input type="submit" value="Upload">
</form>

</div></div>
	
	



	



<script src="https://unpkg.com/@popperjs/core@2"></script> <script src="./js/coreui.min.js"></script>

  <script src="js/modal.js"></script>


  <script src="js/coreui.bundle.js"></script>	</body>
</html>
