<?php

include("config.php");
session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?pesan=belum_login");
	}

// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['upload'])){
	
	// ambil data dari formulir
	$isi = $_POST['isi'];
	$jenis_article = $_POST['jenis_article'];
	
	// buat query
	$sql = "INSERT INTO edit_article (isi, jenis_article) VALUE ('$isi', '$jenis_article')";
	$query = mysqli_query($connect, $sql);
	
	// apakah query simpan berhasil?
	if( $query ) {
		// kalau berhasil alihkan ke halaman form-pendaftaran.php dengan status=sukses
		header('Location: indexadmin.php?status-info=sukses');
	} else {
		// kalau gagal alihkan ke halaman form-pendaftaran.php dengan status=gagal
		header('Location: indexadmin.php?status-info=gagal');
	}
	
	
} else {
	die("Akses dilarang...");
}

?>
