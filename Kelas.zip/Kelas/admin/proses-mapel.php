<?php

include("config.php");
session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?pesan=belum_login");
	}

// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['mapel'])){
	
	// ambil data dari formulir
	$senin = $_POST['senin'];
	$selasa = $_POST['selasa'];
   $rabu = $_POST['rabu'];
	$kamis = $_POST['kamis'];
	$jumat = $_POST['jumat'];
   
	
	// buat query
	$sql = "INSERT INTO jadwal_mapel (senin, selasa, rabu, kamis, jumat) VALUE ('$senin', '$selasa', '$rabu', '$kamis', '$jumat')";
	$query = mysqli_query($connect, $sql);
	
	// apakah query simpan berhasil?
	if( $query ) {
		// kalau berhasil alihkan ke halaman form-pendaftaran.php dengan status=sukses
		header('Location: indexadmin.php?status-mapel=sukses');
	} else {
		// kalau gagal alihkan ke halaman form-pendaftaran.php dengan status=gagal
		header('Location: form-mapel.php?status-mapel=sukses');
	}
	
	
} else {
	die("Akses dilarang...");
}

?>
