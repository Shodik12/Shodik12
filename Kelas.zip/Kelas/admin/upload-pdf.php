<?php
// Load file koneksi.php
include "config.php";
session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?pesan=belum_login");
	}

// Ambil Data yang Dikirim dari Form
$nama_file = $_FILES['pdf']['name'];
$ukuran_file = $_FILES['pdf']['size'];
$tipe_file = $_FILES['pdf']['type'];
$tmp_file = $_FILES['pdf']['tmp_name'];

// Set path folder tempat menyimpan gambarnya
$path = "files/".$nama_file;


if($tipe_file = array ("pdf", "doc", "docx")){ // Cek apakah tipe file yang diupload adalah JPG / JPEG / PNG
	// Jika tipe file yang diupload JPG / JPEG / PNG, lakukan :
	if($ukuran_file <= 10000000){ // Cek apakah ukuran file yang diupload kurang dari sama dengan 1MB
		// Jika ukuran file kurang dari sama dengan 1MB, lakukan :
		// Proses upload
		if(move_uploaded_file($tmp_file, $path)){ // Cek apakah gambar berhasil diupload atau tidak
			// Jika gambar berhasil diupload, Lakukan :	
			// Proses simpan ke Database
			$query = "INSERT INTO pdf(nama_pdf) VALUES('".$nama_file."')";
			$sql = mysqli_query($connect, $query); // Eksekusi/ Jalankan query dari variabel $query
			
			if($sql){ // Cek jika proses simpan ke database sukses atau tidak
				// Jika Sukses, Lakukan :
				header("location: indexadmin.php?status-pdf=sukses"); // Redirectke halaman index.php
			}else{
				// Jika Gagal, Lakukan :
				echo "Maaf, Terjadi kesalahan saat mencoba untuk menyimpan data ke database.";
				echo "<br><a href='indexadmin.php'>Kembali Ke Form</a>";
			}
		}else{
			// Jika gambar gagal diupload, Lakukan :
			echo "Maaf, Gambar gagal untuk diupload.";
			echo "<br><a href='indexadmin.php'>Kembali Ke Form</a>";
		}
	}else{
		// Jika ukuran file lebih dari 1MB, lakukan :
		echo "Maaf, Ukuran gambar yang diupload terlalu besar";
		echo "<br><a href='indexadmin.php'>Kembali Ke Form</a>";
	}
}else{
	// Jika tipe file yang diupload bukan JPG / JPEG / PNG, lakukan :
	echo "Maaf, Tipe gambar yang diupload harus PDF.";
	echo "<br><a href='indexadmin.php'>Kembali Ke Form</a>";
}
?>
