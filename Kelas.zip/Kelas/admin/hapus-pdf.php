<?php
session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?pesan=belum_login");
	}
include("../config.php");

if( isset($_GET['id']) ){
	
	// ambil id dari query string
	$id = $_GET['id'];
	
	// buat query hapus
	$sql = "DELETE FROM pdf WHERE id=$id";
	$query = mysqli_query($connect, $sql);
	
	// apakah query hapus berhasil?
	if( $query ){
		header('Location: indexadmin.php');
	} else {
		die("gagal menghapus...");
	}
	
} else {
	die("akses dilarang...");
}

?>
