<?php include("config.php"); ?>

<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?pesan=belum_login");
	}
	?>
<!DOCTYPE html>
<html>

 <!-- Required meta tags --> <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
<nav class="navbar navbar-dark navbar-light bg-primary"> <!-- Navbar content --> </nav>

<head>
	<title>Formulir Penugasan Siswa</title>
</head>
<!-- JANGAN HILANGKAN CREDIT -->
<meta name="author"content="Shodik12">
  <!-- CoreUI CSS -->
  <link rel="stylesheet" href="./css/coreui.min.css">

   <script src="https://kit.fontawesome.com/a076d05399.js"></script>

  <link rel="stylesheet" href="./css/modal.css">

<body>
	<header>
		<h3>Formulir Tambah Penugasan</h3>
	</header>

<div class="card">
 <div class="card-body"> 


<form action="proses-nugas.php" method="POST">

 <div class="form-group row"> 

<label for="colFormLabelSm" class="col-sm-2 col-form-label col-form-label-sm" name="mapel"><h6>Mata Pelajaran:</label></h6>

 <div class="col-sm-10"> 
<input type="text" class="form-control form-control-sm" id="colFormLabelSm" placeholder="Isi mata pelajaran" name="mapel"> </div> </div> 



 <div class="form-group row"> 

<label for="colFormLabelSm" class="col-sm-2 col-form-label col-form-label-sm" name="materi"><h6>Materi:</label></h6>

<div class="form-group"> 
<label for="exampleFormControlTextarea1">Isi Materi</label> <textarea class="form-control" id="exampleFormControlTextarea1" name="materi" rows="3"></textarea> </div>

</div> 




<br>
<hr>

<div class="form-group row"> 
<div class="col-sm-10">
		
			<button type="submit" class="btn btn-primary" name="nugas" value="Tambah">Tambah
		</button>
		</div></div>

</form>

</div></div>
	
	
	



<script src="https://unpkg.com/@popperjs/core@2"></script> <script src="./js/coreui.min.js"></script>

  <script src=".js/modal.js"></script>


  <script src=".js/coreui.bundle.js"></script>	</body>
</html>
