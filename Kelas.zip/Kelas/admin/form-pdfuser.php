<html>
<head>
	<title>Form Upload Gambar</title>
</head>
<body>
<h1>Form Upload Gambar</h1>
<form method="post" enctype="multipart/form-data" action="upload-pdfuser.php">
	<input type="file" name="pdf">
	<input type="submit" value="Upload">
</form>
</body>
</html>
