<?php

include("config.php");
session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?pesan=belum_login");
	}


// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['soal'])){
	
	// ambil data dari formulir
	$soal = $_POST['soal'];
   $js = $_POST['jawaban_siswa'];
   $jg = $_POST['jawaban_guru'];
	$pila = $_POST['pila'];
   $pilb = $_POST['pilb'];
   $pilc = $_POST['pilc'];
	
	// buat query
	$sql = "INSERT INTO uts (soal, jawaban_siswa, jawaban_guru, pila, pilb, pilc) VALUE ('$soal', '$js', '$jg' '$pila', '$pilb', '$pilc')";
	$query = mysqli_query($connect, $sql);
	
	// apakah query simpan berhasil?
	if( $query ) {
		// kalau berhasil alihkan ke halaman form-pendaftaran.php dengan status=sukses
		header('Location: index.php');
	} else {
		// kalau gagal alihkan ke halaman form-pendaftaran.php dengan status=gagal
		header('Location: index.php?status-siswa=gagal');
	}
	
	
} else {
	die("Akses dilarang...");
}

?>
