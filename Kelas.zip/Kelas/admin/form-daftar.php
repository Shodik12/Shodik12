<?php include("config.php"); ?>

<?php 
	session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?pesan=belum_login");
	}
	?>
<!DOCTYPE html>
<html>

 <!-- Required meta tags --> <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
<nav class="navbar navbar-dark navbar-light bg-primary"> <!-- Navbar content --> </nav>

<head>
	<title>Formulir Pendaftaran Siswa Baru </title>
</head>
<!-- JANGAN HILANGKAN CREDIT -->
<meta name="author"content="Shodik12">
  <!-- CoreUI CSS -->
  <link rel="stylesheet" href="css/coreui.min.css">

   <script src="https://kit.fontawesome.com/a076d05399.js"></script>

  <link rel="stylesheet" href="css/modal.css">

<body>
	<header>
		<h3>Formulir Pendaftaran Siswa Baru</h3>
	</header>

<div class="card">
 <div class="card-body"> 


<form action="proses-pendaftaran.php" method="POST">

 <div class="form-group row"> 

<label for="colFormLabelSm" class="col-sm-2 col-form-label col-form-label-sm" name="nama"><h6>Nama Siswa</label></h6>

 <div class="col-sm-10"> 
<input type="text" class="form-control form-control-sm" id="colFormLabelSm" placeholder="Isi nama" name="nama"> </div> </div> 




<div class="btn btn-outline-dark" data-toggle="buttons"><h6> Jenis Kelamin:</h6><br>
<label class="btn btn-outline-dark"> <input type="radio" name="jenis_kelamin" id="option1" autocomplete="off" value="Laki-laki" checked> Laki-Laki </label>

 <label class="btn btn-outline-dark"> <input type="radio" name="jenis_kelamin" id="option2" autocomplete="off" value="Perempuan"> Perempuan </label> 


 </div>



<br>
<hr>

<div class="form-group row"> 
<div class="col-sm-10">
		
			<button type="submit" class="btn btn-primary" name="daftar" value="Tambah">Tambah
		</button>
		</div></div>

</form>

</div></div>
	
	
	



<script src="https://unpkg.com/@popperjs/core@2"></script> <script src="./js/coreui.min.js"></script>

  <script src="js/modal.js"></script>


  <script src="js/coreui.bundle.js"></script>	</body>
</html>
