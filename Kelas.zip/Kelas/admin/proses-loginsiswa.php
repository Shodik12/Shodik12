<?php


include("config.php");
session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?pesan=belum_login");
	}

// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['loginsiswa'])){
	
	// ambil data dari formulir
	$nama = $_POST['nama'];
   	$password = $_POST['password'];
	
	
	// buat query
	$sql = "INSERT INTO login_siswa (nama, password) VALUE ('$nama', '$password')";
	$query = mysqli_query($connect, $sql);


	$cek = mysqli_num_rows($query);

if($cek > 0){
	$_SESSION['nama'] = $nama;
	$_SESSION['status'] = "login";
	header("location:siswa/index.php");
}else{
	header("location:index.php/?pesan=gagal");
}
	// apakah query simpan berhasil?
	if( $query ) {
		// kalau berhasil alihkan ke halaman form-pendaftaran.php dengan status=sukses
		header('Location:siswa/index.php');
	} else {
		// kalau gagal alihkan ke halaman form-pendaftaran.php dengan status=gagal
		header('Location:index.php?status-siswa=gagal');
	}
	
	
} else {
	die("Akses dilarang...");
}

?>
