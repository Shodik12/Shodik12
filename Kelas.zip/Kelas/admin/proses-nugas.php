<?php

include("../config.php");
session_start();
	if($_SESSION['status']!="login"){
		header("location:../index.php?pesan=belum_login");
	}

// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['nugas'])){
	
	// ambil data dari formulir
	$mapel = $_POST['mapel'];
	$materi = $_POST['materi'];

	
	// buat query
	$sql = "INSERT INTO tugas (mapel, materi) VALUE ('$mapel',  '$materi')";
	$query = mysqli_query($connect, $sql);
	
	// apakah query simpan berhasil?
	if( $query ) {
		// kalau berhasil alihkan ke halaman form-pendaftaran.php dengan status=sukses
		header('Location: indexadmin.php?status-tugas=sukses');
	} else {
		// kalau gagal alihkan ke halaman form-pendaftaran.php dengan status=gagal
		header('Location: indexadmin.php?status-tugas=gagal');
	}
	
	
} else {
	die("Akses dilarang...");
}

?>
