<html>
<head>
	<title>Multiple Insert</title>
	<script src="jquery.min.js" type="text/javascript"></script>
</head>
<body>
	<h1>Multiple Insert</h1>
	
	<form method="post" action="proses-uts.php">
		<!-- Buat tombol untuk menabah form data -->
		<button type="button" id="btn-tambah-form">Tambah Data Form</button>
		<button type="button" id="btn-reset-form">Reset Form</button><br><br>
		
		<b>Data ke 1 :</b>
		<table>
			<tr>
				<td>NIS</td>
				<td><input type="text" name="soal" required></td>
			</tr>
			<tr>
				<td>Nama</td>
				<td><input type="text" name="jawaban_guru" required></td>
			</tr>
			<tr>
				<td>Telepon</td>
				<td><input type="text" name="pila" required></td>
			</tr>
			<tr>
				
			</tr>
	<tr>
				<td>Telepon</td>
				<td><input type="text" name="pilb" required></td>
			</tr>
			<tr>
				
			</tr>

	<tr>
				<td>Telepon</td>
				<td><input type="text" name="pilc" required></td>
			</tr>
			<tr>
				
			</tr>
		</table>
		<br><br>

		<div id="insert-form"></div>
		
		<hr>
		<input type="submit" value="Simpan" name="soal">
	</form>
	
	
</body>
</html>
