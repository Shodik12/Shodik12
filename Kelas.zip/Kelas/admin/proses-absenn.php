<?php

include("config.php");

// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['absen'])){
	
	// ambil data dari formulir
	$nama = $_POST['nama'];
	$hari = $_POST['hari'];
   $ket = $_POST['ket'];
	
	// buat query
	$sql = "INSERT INTO absen_siswa (nama, hari, ket) VALUE ('$nama', '$hari', '$ket')";
	$query = mysqli_query($connect, $sql);
	
	// apakah query simpan berhasil?
	if( $query ) {
		// kalau berhasil alihkan ke halaman form-pendaftaran.php dengan status=sukses
		header('Location: index.php');
	} else {
		// kalau gagal alihkan ke halaman form-pendaftaran.php dengan status=gagal
		header('Location: absen.php');
	}
	
	
} else {
	die("Akses dilarang...");
}

?>
