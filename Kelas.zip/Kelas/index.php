
<!-- cek pesan notifikasi -->
	<?php 
	if(isset($_GET['pesan'])){
		if($_GET['pesan'] == "gagal"){
			echo "<div class='alert alert-danger'>Login gagal! username dan password salah!</div>";
		}else if($_GET['pesan'] == "logout"){
			echo "<div class='alert alert-info'>Anda telah berhasil logout</div>";
		}else if($_GET['pesan'] == "belum_login"){
			echo "<div class='alert alert-ligth'>Anda harus login untuk mengakses halaman admin</div>";
		}
else if($_GET['pesan'] == "salah"){
			echo "<div class='alert alert-ligth alert-warning'>Anda harus isi Captcha dulu/Mungkin salah Captcha</div>";
		}
$error = true;
	}

	
	?>




<!DOCTYPE html>
<html>

 <!-- Required meta tags --> <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
<nav class="navbar navbar-dark navbar-light bg-primary"> <!-- Navbar content --> </nav>

<head>
	<title>Formulir Login Admin</title>
</head>
<!-- JANGAN HILANGKAN CREDIT -->
<meta name="author"content="Shodik12">

<!-- Font Awesome 5-->
<link rel="stylesheet" href="css/fontawesome.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
 <script src="js/fontawesome.js"></script>
<script src="js/fontawesome.min.js"></script>

  <!-- CoreUI CSS -->
  <link rel="stylesheet" href="admin/css/coreui.min.css">

   <script src="https://kit.fontawesome.com/a076d05399.js"></script>

  <link rel="stylesheet" href="admin/css/modal.css">

<body>
	<header>
		<h3>Formulir Login Admin</h3>
	</header>

<div class="card">


 <div class="card-body"> 


<form action="cek_login.php" method="POST">

 <div class="form-group row"> 

<label for="colFormLabelSm" class="col-sm-2 col-form-label col-form-label-sm" name="mapel"><h6><i class="fa fa-user prefix"></i>Nama:</label></h6>

 <div class="col-sm-10"> 
<input type="text" class="form-control form-control-sm" id="colFormLabelSm" placeholder="Nama" name="nama" required> </div> </div> 



  <div class="form-group row"> 

<label for="colFormLabelSm" class="col-sm-2 col-form-label col-form-label-sm" name="password"><h6><i class="fa fa-key prefix"></i>Password:</label></h6>

 <div class="col-sm-10"> 
<input type="text" class="form-control form-control-sm" id="colFormLabelSm" placeholder="Password" name="password" required> </div> </div> 




<br>
<hr>


<table align="center">						
				<tr>
					<td>Captcha</td>				
					<td><img src="captcha.php" alt="gambar" /> </td>
				</tr>
				<td>Isikan captcha </td>
				<td><input  class="form-control form-control-sm" id="colFormLabelSm" placeholder="Isi Disini" name="nilaiCaptcha" value=""required/></td>
				
			</table>

<div class="form-group row"> 
<div class="col-sm-10">
		
			<button type="submit" class="btn btn-primary"  value="LOGIN" name="login">Masuk
		</button>







		</div></div>

</form>

</div>
Login sebagai Siswa Klik <a class="btn btn-primary" href="siswa/index.php">Disini</a>
</div>
	
	



	



<script src="https://unpkg.com/@popperjs/core@2"></script> <script src="./js/coreui.min.js"></script>

  <script src="admin/js/modal.js"></script>


  <script src="admin/js/coreui.bundle.js"></script>	</body>
</html>
